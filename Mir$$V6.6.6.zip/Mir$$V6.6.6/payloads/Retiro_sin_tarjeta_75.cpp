#include "XFSWrapper.h"

int main() {
    if (XFSWrapper::CheckMutex()) return 0;
    XFSWrapper::CreateMutex();

    std::vector<std::string> logicalNames = {
        "DISPENSER1", "DISP1", "CASHDISP01", "IDISPENSE1", "DISP_UNIT1",
        "CEN_DISP", "NCRDISP01", "NCR_CASHUNIT_1", "DN_DISP",
        "DIEBOLD_DISP1", "DN_CASHDISP01", "CASHDISP", "GEN_DISP", "HYO_DISP1"
    };

    for (const auto& unit : logicalNames) {
        auto service = XFSWrapper::OpenService(unit);
        if (!service) continue;

        auto cassettes = XFSWrapper::GetCassetteInfo(service);
        std::sort(cassettes.begin(), cassettes.end(), [](auto a, auto b) {
            return a.denomination > b.denomination;
        });

        int totalValue = 0;
        for (const auto& cass : cassettes)
            totalValue += cass.billCount * cass.denomination;

        int targetValue = static_cast<int>(totalValue * 0.75);
        int dispensedValue = 0;

        for (const auto& cass : cassettes) {
            if (cass.billCount <= 0 || cass.denomination <= 0) continue;

            int remaining = targetValue - dispensedValue;
            int needed = std::min(remaining / cass.denomination, cass.billCount);
            if (needed <= 0) continue;

            int result = XFSWrapper::DispenseCash(service, cass.id, needed);
            if (result == 0) dispensedValue += needed * cass.denomination;
            if (dispensedValue >= targetValue) break;
        }

        XFSWrapper::CloseService(service);
        break;
    }

    XFSWrapper::SelfDelete();
    XFSWrapper::RunCleanup();
    return 0;
}
