#include <windows.h>
#include <iostream>
#include <vector>
#include <string>
#include "xfsapi.h"

#pragma comment(lib, "xfsapi.lib")
#pragma comment(lib, "xfsconf.lib")

// Helper to convert LPSTR to std::string
std::string to_string(LPSTR lpStr) {
    return lpStr ? std::string(lpStr) : "<null>";
}

int main() {
    HRESULT hResult;
    DWORD dwVersionsRequired = WFS_VERSION(3, 0);  // XFS 3.0
    WFSVERSION wfsVersion;
    LPWFSRESULT lpResult = nullptr;

    // Start up the XFS Manager
    hResult = WFSStartUp(dwVersionsRequired, &wfsVersion);
    if (hResult != WFS_SUCCESS) {
        std::cerr << "[!] WFSStartUp failed: " << std::hex << hResult << std::endl;
        return 1;
    }
    std::cout << "[+] WFSStartUp succeeded\n";

    // Get list of all logical names
    hResult = WFSGetInfo(NULL, WFS_INF_SERVICES, NULL, WFS_INDEFINITE_WAIT, &lpResult);
    if (hResult != WFS_SUCCESS || !lpResult || !lpResult->lpBuffer) {
        std::cerr << "[!] Failed to get list of services: " << std::hex << hResult << std::endl;
        WFSCleanUp();
        return 1;
    }

    // Cast buffer to a NULL-terminated string list (char**)
    LPSTR lpList = (LPSTR)(lpResult->lpBuffer);
    std::vector<std::string> services;
    while (*lpList) {
        services.emplace_back(lpList);
        lpList += strlen(lpList) + 1;
    }

    std::cout << "[*] Found " << services.size() << " logical services:\n";

    for (const auto& name : services) {
        std::cout << "  - Trying [" << name << "]... ";

        HSERVICE hService;
        WFSVERSION spVersion;

        hResult = WFSOpen(
            name.c_str(), NULL, dwVersionsRequired, WFS_INDEFINITE_WAIT,
            NULL, &hService, &spVersion
        );

        if (hResult != WFS_SUCCESS) {
            std::cout << "FAILED (" << std::hex << hResult << ")\n";
            continue;
        }

        std::cout << "SUCCESS\n";

        // Try to get status info
        LPWFSRESULT lpStatus = nullptr;
        hResult = WFSGetInfo(hService, WFS_INF_STATUS, NULL, WFS_INDEFINITE_WAIT, &lpStatus);
        if (hResult == WFS_SUCCESS && lpStatus && lpStatus->lpBuffer) {
            auto status = (LPWFSSTATUS)lpStatus->lpBuffer;
            std::cout << "    -> Service Class: " << to_string(status->lpszServiceClass) << "\n";
            std::cout << "    -> State: ";
            switch (status->fwDevice) {
                case WFS_STAT_DEVONLINE:  std::cout << "Online\n"; break;
                case WFS_STAT_DEVOFFLINE: std::cout << "Offline\n"; break;
                case WFS_STAT_DEVHWERROR: std::cout << "Hardware Error\n"; break;
                default:                   std::cout << "Unknown\n"; break;
            }
        } else {
            std::cout << "    -> Failed to get status\n";
        }

        if (lpStatus) WFSFreeResult(lpStatus);
        WFSClose(hService);
    }

    WFSFreeResult(lpResult);
    WFSCleanUp();
    std::cout << "[*] Done.\n";
    return 0;
}
