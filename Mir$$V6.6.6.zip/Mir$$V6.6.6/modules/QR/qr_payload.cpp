// qr_payload.cpp

#include <qrencode.h>
#include <png.h>
#include <string>
#include <iostream>
#include <vector>
#include <cstdio>

#define PIXEL_SIZE 10
#define MARGIN 4

bool writePNG(const std::string& filename, QRcode* qrcode) {
    FILE* fp = fopen(filename.c_str(), "wb");
    if (!fp) return false;

    png_structp png = png_create_write_struct(PNG_LIBPNG_VER_STRING, nullptr, nullptr, nullptr);
    if (!png) return false;

    png_infop info = png_create_info_struct(png);
    if (!info) return false;

    if (setjmp(png_jmpbuf(png))) return false;

    png_init_io(png, fp);

    int size = qrcode->width + MARGIN * 2;
    int image_size = size * PIXEL_SIZE;

    png_set_IHDR(png, info, image_size, image_size,
                 8, PNG_COLOR_TYPE_GRAY, PNG_INTERLACE_NONE,
                 PNG_COMPRESSION_TYPE_BASE, PNG_FILTER_TYPE_BASE);

    png_write_info(png, info);

    std::vector<png_bytep> rows(image_size);
    for (int y = 0; y < image_size; ++y) {
        rows[y] = new png_byte[image_size];
        for (int x = 0; x < image_size; ++x) {
            int qrx = x / PIXEL_SIZE - MARGIN;
            int qry = y / PIXEL_SIZE - MARGIN;
            bool pixel = (qrx >= 0 && qrx < qrcode->width && qry >= 0 && qry < qrcode->width)
                         ? qrcode->data[qry * qrcode->width + qrx] & 0x01
                         : false;
            rows[y][x] = pixel ? 0 : 255;
        }
    }

    png_write_image(png, rows.data());
    png_write_end(png, nullptr);

    for (auto row : rows) delete[] row;
    fclose(fp);
    png_destroy_write_struct(&png, &info);

    return true;
}

int main() {
    std::string payloadURL = "https://your-c2-server/payload.ps1";
    QRcode* qr = QRcode_encodeString(payloadURL.c_str(), 0, QR_ECLEVEL_Q, QR_MODE_8, 1);
    
    if (!qr) {
        std::cerr << "[-] Failed to generate QR code." << std::endl;
        return 1;
    }

    if (writePNG("payload_qr.png", qr)) {
        std::cout << "[+] QR Code written to payload_qr.png" << std::endl;
    } else {
        std::cerr << "[-] Failed to write PNG file." << std::endl;
    }

    QRcode_free(qr);
    return 0;
}