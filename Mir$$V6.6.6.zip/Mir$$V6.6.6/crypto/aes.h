#pragma once
#include <string>
#include <vector>

namespace AESGCM {
    bool EncryptFile(const std::string& inputFile, const std::string& outputFile, const std::vector<unsigned char>& key, const std::vector<unsigned char>& iv);
}
