#include <windows.h>
#include <wincrypt.h>
#include <vector>
#include <string>
#include <iostream>
#include <fstream>

// Hardcoded AES key (256-bit)
const BYTE AES_KEY[32] = {
    0x60, 0x3d, 0xeb, 0x10, 0x15, 0xca, 0x71, 0xbe,
    0x2b, 0x73, 0xae, 0xf0, 0x85, 0x7d, 0x77, 0x81,
    0x1f, 0x35, 0x2c, 0x07, 0x3b, 0x61, 0x08, 0xd7,
    0x2d, 0x98, 0x10, 0xa3, 0x09, 0x14, 0xdf, 0xf4
};

// Helper: Read entire file into vector<byte>
bool ReadFileToBytes(const std::string& path, std::vector<BYTE>& outBytes) {
    std::ifstream file(path, std::ios::binary);
    if (!file) return false;

    file.seekg(0, std::ios::end);
    size_t size = file.tellg();
    file.seekg(0, std::ios::beg);

    outBytes.resize(size);
    file.read(reinterpret_cast<char*>(outBytes.data()), size);
    return file.good();
}

// Helper: Convert base64 string to bytes
bool Base64Decode(const std::string& base64, std::vector<BYTE>& outBytes) {
    DWORD outLen = 0;
    if (!CryptStringToBinaryA(base64.c_str(), 0, CRYPT_STRING_BASE64, NULL, &outLen, NULL, NULL))
        return false;

    outBytes.resize(outLen);
    if (!CryptStringToBinaryA(base64.c_str(), 0, CRYPT_STRING_BASE64, outBytes.data(), &outLen, NULL, NULL))
        return false;

    outBytes.resize(outLen);
    return true;
}

// AES-GCM decrypt using Windows CNG API (BCrypt)
bool AESGCM_Decrypt(
    const std::vector<BYTE>& ciphertextWithTag,
    const std::vector<BYTE>& iv,
    std::vector<BYTE>& plaintext)
{
    if (iv.size() != 12) {
        std::cerr << "IV must be 12 bytes for AES-GCM" << std::endl;
        return false;
    }
    if (ciphertextWithTag.size() < 16) {
        std::cerr << "Ciphertext
