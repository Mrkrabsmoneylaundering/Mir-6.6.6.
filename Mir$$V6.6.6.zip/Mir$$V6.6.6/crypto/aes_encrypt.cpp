#include "aes.h"
#include <fstream>
#include <vector>
#include <windows.h>
#include <bcrypt.h>

#pragma comment(lib, "bcrypt.lib")

bool AESGCM::EncryptFile(const std::string& inputFile, const std::string& outputFile, const std::vector<unsigned char>& key, const std::vector<unsigned char>& iv) {
    NTSTATUS status;
    BCRYPT_ALG_HANDLE hAlg = nullptr;
    BCRYPT_KEY_HANDLE hKey = nullptr;
    DWORD cbData = 0, cbKeyObject = 0, cbTag = 16;
    std::vector<unsigned char> pbKeyObject, tag(cbTag);

    // Read input plaintext file
    std::ifstream infile(inputFile, std::ios::binary);
    if (!infile) return false;
    std::vector<unsigned char> plainData((std::istreambuf_iterator<char>(infile)), std::istreambuf_iterator<char>());
    infile.close();

    std::vector<unsigned char> cipherData(plainData.size());

    // Open algorithm provider
    status = BCryptOpenAlgorithmProvider(&hAlg, BCRYPT_AES_ALGORITHM, NULL, 0);
    if (!BCRYPT_SUCCESS(status)) return false;

    // Set GCM mode
    status = BCryptSetProperty(hAlg, BCRYPT_CHAINING_MODE, (PUCHAR)BCRYPT_CHAIN_MODE_GCM, sizeof(BCRYPT_CHAIN_MODE_GCM), 0);
    if (!BCRYPT_SUCCESS(status)) {
        BCryptCloseAlgorithmProvider(hAlg, 0);
        return false;
    }

    // Calculate key object size
    status = BCryptGetProperty(hAlg, BCRYPT_OBJECT_LENGTH, (PUCHAR)&cbKeyObject, sizeof(DWORD), &cbData, 0);
    if (!BCRYPT_SUCCESS(status)) {
        BCryptCloseAlgorithmProvider(hAlg, 0);
        return false;
    }

    pbKeyObject.resize(cbKeyObject);

    // Generate key handle
    status = BCryptGenerateSymmetricKey(hAlg, &hKey, pbKeyObject.data(), cbKeyObject, (PUCHAR)key.data(), key.size(), 0);
    if (!BCRYPT_SUCCESS(status)) {
        BCryptCloseAlgorithmProvider(hAlg, 0);
        return false;
    }

    // Setup GCM Auth Info
    BCRYPT_AUTHENTICATED_CIPHER_MODE_INFO authInfo;
    BCRYPT_INIT_AUTH_MODE_INFO(authInfo);
    authInfo.pbNonce = (PUCHAR)iv.data();
    authInfo.cbNonce = iv.size();
    authInfo.pbTag = tag.data();
    authInfo.cbTag = cbTag;

    // Perform encryption
    status = BCryptEncrypt(hKey, plainData.data(), plainData.size(), &authInfo, NULL, 0, cipherData.data(), cipherData.size(), &cbData, 0);
    if (!BCRYPT_SUCCESS(status)) {
        BCryptDestroyKey(hKey);
        BCryptCloseAlgorithmProvider(hAlg, 0);
        return false;
    }

    // Write [Tag (16 bytes)] + [CipherText] to output file
    std::ofstream outfile(outputFile, std::ios::binary);
    if (!outfile) {
        BCryptDestroyKey(hKey);
        BCryptCloseAlgorithmProvider(hAlg, 0);
        return false;
    }
    outfile.write((char*)tag.data(), tag.size());
    outfile.write((char*)cipherData.data(), cipherData.size());
    outfile.close();

    BCryptDestroyKey(hKey);
    BCryptCloseAlgorithmProvider(hAlg, 0);

    return true;
}
