import qrcode
import os

# Base URL for QR code generation
BASE_URL = "https://10.14.231.206:443"

# Stub and payload identifiers
stubs = ["stub1", "stub2", "stub3"]
payloads = ["payload1", "payload2", "payload3"]

# Output directory
output_dir = "qr_codes"
os.makedirs(output_dir, exist_ok=True)

def save_qr(name, url):
    img = qrcode.make(url)
    img_path = os.path.join(output_dir, f"{name}.png")
    img.save(img_path)
    print(f"✅ Saved QR for {name}: {url}")

# Generate QR codes for stubs
for stub in stubs:
    url = f"{BASE_URL}/{stub}"
    save_qr(stub, url)

# Generate QR codes for payloads
for payload in payloads:
    url = f"{BASE_URL}/{payload}"
    save_qr(payload, url)
