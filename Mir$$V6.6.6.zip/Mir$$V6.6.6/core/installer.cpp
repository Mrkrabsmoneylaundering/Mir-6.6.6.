// installer.cpp

#include <windows.h>
#include <iostream>
#include <fstream>
#include <filesystem>  // C++17

int wmain() {
    const wchar_t* folder = L"C:\\ProgramData\\Mir$$++";
    const wchar_t* src = L"cleanup.exe";
    const wchar_t* dst = L"C:\\ProgramData\\Mir$$++\\cleanup.exe";

    std::wcout << L"[*] Deploying cleanup.exe to ProgramData..." << std::endl;

    // Create directory (and parent directories) if not exists
    std::error_code ec;
    std::filesystem::create_directories(folder, ec);
    if (ec) {
        std::wcerr << L"[!] Failed to create directory: " << ec.message().c_str() << std::endl;
        return 1;
    }

    // Copy file
    if (!CopyFileW(src, dst, FALSE)) {
        std::wcerr << L"[!] Failed to copy file: " << GetLastError() << std::endl;
        return 1;
    }

    std::wcout << L"[+] cleanup.exe deployed successfully." << std::endl;
    return 0;
}
