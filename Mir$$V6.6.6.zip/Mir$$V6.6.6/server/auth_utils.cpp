from flask import request, jsonify
import json

CONFIG = json.load(open('config.json'))

def require_auth(func):
    def wrapper(*args, **kwargs):
        token = request.headers.get('X-Auth-Token')
        if token != CONFIG['auth_token']:
            return jsonify({'error': 'unauthorized'}), 403
        return func(*args, **kwargs)
    wrapper.__name__ = func.__name__
    return wrapper

def get_client_ip(req):
    if 'X-Forwarded-For' in req.headers:
        return req.headers['X-Forwarded-For'].split(',')[0]
    return req.remote_addr
