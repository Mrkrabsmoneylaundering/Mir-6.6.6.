# utils/memory_store.py

import json
import os

class MemoryStore:
    def __init__(self):
        self.data = {}

    def load_payloads(self):
        base_dir = os.path.join(os.path.dirname(__file__), "..", "client")
        payload_path = os.path.join(base_dir, "win10_payload.json")
        
        if os.path.exists(payload_path):
            with open(payload_path, "r", encoding="utf-8") as f:
                self.data["win10"] = json.load(f)
        else:
            print(f"Payload file not found at {payload_path}")

    def get(self, name):
        return self.data.get(name)
