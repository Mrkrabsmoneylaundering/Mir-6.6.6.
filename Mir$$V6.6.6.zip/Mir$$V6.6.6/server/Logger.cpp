#include <windows.h>
#include <shlobj.h>
#include <string>
#include <fstream>
#include <iostream>
#include <chrono>
#include <iomanip>
#include <ctime>

std::string getProgramDataPath() {
    char path[MAX_PATH];
    if (SUCCEEDED(SHGetFolderPathA(NULL, CSIDL_COMMON_APPDATA, NULL, 0, path))) {
        return std::string(path);
    }
    return "";
}

std::string getCurrentUTCTime() {
    using namespace std::chrono;
    auto now = system_clock::now();
    std::time_t now_time_t = system_clock::to_time_t(now);
    std::tm utc_tm;
    gmtime_s(&utc_tm, &now_time_t);

    char buffer[100];
    std::strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S UTC", &utc_tm);
    return std::string(buffer);
}

std::string getUsername() {
    char username[256];
    DWORD size = sizeof(username);
    if (GetUserNameA(username, &size)) {
        return std::string(username);
    }
    return "UnknownUser";
}

void logStubExecution() {
    std::string logDir = getProgramDataPath() + "\\WinSystem";
    CreateDirectoryA(logDir.c_str(), NULL); // Ensure directory exists

    std::string logFile = logDir + "\\logs.txt";

    std::ofstream logStream(logFile, std::ios_base::app);
    if (!logStream.is_open()) {
        std::cerr << "Failed to open log file: " << logFile << std::endl;
        return;
    }

    std::string logEntry = getCurrentUTCTime() + " Ejecutado Stub en el usuario: " + getUsername() + "\n";

    logStream << logEntry;
    logStream.close();
}

int main() {
    logStubExecution();
    return 0;
}
