#include <windows.h>
#include <shlobj.h>
#include <iostream>
#include <fstream>

void deleteFile(const std::string& path) {
    DeleteFileA(path.c_str());
}

void removeRegistryRunEntry(const std::string& valueName) {
    HKEY hKey;
    const char* subKey = "Software\\Microsoft\\Windows\\CurrentVersion\\Run";
    if (RegOpenKeyExA(HKEY_CURRENT_USER, subKey, 0, KEY_SET_VALUE, &hKey) == ERROR_SUCCESS) {
        RegDeleteValueA(hKey, valueName.c_str());
        RegCloseKey(hKey);
    }
}

void removeScheduledTask(const std::string& taskName) {
    std::string command = "schtasks /Delete /TN \"" + taskName + "\" /F >nul 2>&1";
    system(command.c_str());
}

void scheduleSelfDeletion(const std::string& selfPath) {
    std::string cmd = "cmd /c timeout 2 >nul & del \"" + selfPath + "\"";
    ShellExecuteA(nullptr, "open", "cmd.exe", ("/c " + cmd).c_str(), nullptr, SW_HIDE);
}

int main() {
    char programData[MAX_PATH];
    SHGetFolderPathA(nullptr, CSIDL_COMMON_APPDATA, nullptr, 0, programData);

    std::string basePath = std::string(programData) + "\\WinSystem\\";
    std::string payloadPath = basePath + "winshell.ps1";
    std::string logPath = basePath + "logs.txt";
    std::string taskName = "WinShellBoot";
    std::string regValue = "WinShellLoader";

    removeScheduledTask(taskName);
    removeRegistryRunEntry(regValue);
    deleteFile(payloadPath);
    deleteFile(logPath);

    char selfPath[MAX_PATH];
    GetModuleFileNameA(nullptr, selfPath, MAX_PATH);
    scheduleSelfDeletion(selfPath);

    return 0;
}
