#pragma once
#include <string>
#include <unordered_map>

bool loadConfig(const std::string& path = "config.json");
bool requireAuth(const std::unordered_map<std::string, std::string>& headers);
std::string getClientIP(const std::unordered_map<std::string, std::string>& headers, const std::string& remoteAddr);
