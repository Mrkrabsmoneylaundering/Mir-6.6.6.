#include <iostream>
#include <fstream>
#include <string>
#include <vector>

#include <cryptopp/aes.h>
#include <cryptopp/modes.h>
#include <cryptopp/filters.h>
#include <cryptopp/base64.h>
#include <cryptopp/secblock.h>

void encryptFile(const std::string& inputFile, const std::string& outputFile) {
    // Key and IV must be exactly 16 bytes
    const byte key[CryptoPP::AES::DEFAULT_KEYLENGTH] = 
        { 'T','u','C','l','a','v','e','D','e','1','6','B','y','t','e','s' };
    const byte iv[CryptoPP::AES::BLOCKSIZE] = 
        { '1','6','B','y','t','e','I','n','i','t','V','e','c','t','o','r' };

    // Read input file bytes
    std::ifstream fileIn(inputFile, std::ios::binary);
    if (!fileIn) {
        std::cerr << "Error opening input file.\n";
        return;
    }
    std::vector<byte> buffer((std::istreambuf_iterator<char>(fileIn)), std::istreambuf_iterator<char>());
    fileIn.close();

    // Padding with spaces to multiple of 16 bytes
    size_t paddingSize = CryptoPP::AES::BLOCKSIZE - (buffer.size() % CryptoPP::AES::BLOCKSIZE);
    if (paddingSize != CryptoPP::AES::BLOCKSIZE) {
        buffer.insert(buffer.end(), paddingSize, ' ');
    }

    // Encrypt with AES CBC mode
    CryptoPP::CBC_Mode<CryptoPP::AES>::Encryption encryptor(key, sizeof(key), iv);
    std::string cipherText;

    CryptoPP::StringSource ss(buffer.data(), buffer.size(), true,
        new CryptoPP::StreamTransformationFilter(encryptor,
            new CryptoPP::StringSink(cipherText)
        )
    );

    // Base64 encode ciphertext
    std::string encoded;
    CryptoPP::StringSource ss2(cipherText, true,
        new CryptoPP::Base64Encoder(
            new CryptoPP::StringSink(encoded),
            false // no line breaks
        )
    );

    // Write output file
    std::ofstream fileOut(outputFile, std::ios::binary);
    if (!fileOut) {
        std::cerr << "Error opening output file.\n";
        return;
    }
    fileOut << encoded;
    fileOut.close();

    std::cout << "Encryption complete: " << outputFile << std::endl;
}

int main() {
    encryptFile("payload.ps1", "payload.enc");
    return 0;
}
