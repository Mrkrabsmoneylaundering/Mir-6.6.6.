# server/dispatcher.py

from http.server import BaseHTTPRequestHandler
from urllib.parse import urlparse
import json

def create_handler(api_instance):
    class Dispatcher(BaseHTTPRequestHandler):
        def do_GET(self):
            parsed_path = urlparse(self.path).path
            if parsed_path == "/payloads/win10":
                result = api_instance.get_payload("win10")
                self._send_json(result)
            else:
                self.send_response(404)
                self.end_headers()
                self.wfile.write(b"Not found")

        def _send_json(self, payload):
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            if isinstance(payload, str):
                self.wfile.write(payload.encode())
            else:
                self.wfile.write(json.dumps(payload).encode())

    return Dispatcher
