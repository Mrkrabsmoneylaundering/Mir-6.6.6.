# server/wfsapi.py

from utils.memory_store import MemoryStore

class WFSAPI:
    def __init__(self):
        self.store = MemoryStore()
        self.store.load_payloads()

    def get_payload(self, name):
        payload = self.store.get(name)
        if not payload:
            return {"error": f"Payload '{name}' not found"}
        return payload
