# main.py

from server.wfsapi import WFSAPI
from server.dispatcher import create_handler
from http.server import HTTPServer

def run_server():
    # Create WFSAPI instance
    api = WFSAPI()
    
    # Create the request handler bound with API
    handler_class = create_handler(api)

    # Start HTTP server
    server_address = ("0.0.0.0", 8080)
    httpd = HTTPServer(server_address, handler_class)
    print(f"Server running at http://{server_address[0]}:{server_address[1]}")
    httpd.serve_forever()

if __name__ == "__main__":
    run_server()
