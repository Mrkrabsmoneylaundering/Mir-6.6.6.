#include <windows.h>
#include <XFSSPI.H>
#include <iostream>
#include <vector>
#include <string>

#pragma comment(lib, "WFSAPI.lib")

std::vector<std::string> logicalNames = {
    "DISP1", "DISPENSER1", "CASHDISP01", "IDISPENSE1", "DISP_UNIT1",
    "CEN_DISP", "NCRDISP01", "NCR_CASHUNIT_1", "DN_DISP", "DIEBOLD_DISP1",
    "DN_CASHDISP01", "CASHDISP", "GEN_DISP", "HYO_DISP1"
};

std::string GetCassetteStatus(WORD status) {
    switch (status) {
    case WFS_CIM_OK: return "OK";
    case WFS_CIM_FULL: return "FULL";
    case WFS_CIM_LOW: return "LOW";
    case WFS_CIM_EMPTY: return "EMPTY";
    case WFS_CIM_INOP: return "INOP";
    case WFS_CIM_MISSING: return "MISSING";
    case WFS_CIM_HIGH: return "HIGH";
    default: return "UNKNOWN";
    }
}

void QueryCassettes(const std::string& logicalName) {
    HRESULT hResult;
    HSERVICE hService;
    WFSRESULT* lpResult = nullptr;

    hResult = WFSStartUp(WFS_VERSION, nullptr);
    if (hResult != WFS_SUCCESS) return;

    hResult = WFSOpen(logicalName.c_str(), WFS_DEFAULT_HAPP, "ATM_QUERY", WFS_TRACE_API, WFS_INDEFINITE_WAIT, nullptr, &hService);
    if (hResult != WFS_SUCCESS) {
        WFSCleanUp();
        return;
    }

    hResult = WFSGetInfo(hService, WFS_INF_CIM_CASHUNITINFO, nullptr, WFS_INDEFINITE_WAIT, &lpResult);
    if (hResult == WFS_SUCCESS && lpResult) {
        LPWFSCIMCASHINFO lpCashInfo = (LPWFSCIMCASHINFO)lpResult->lpBuffer;
        for (DWORD i = 0; i < lpCashInfo->usCount; i++) {
            LPWFSCIMCASHUNIT lpUnit = lpCashInfo->lppCashUnitList[i];
            printf("[Cassette %d] ID: %s | Currency: %.3s | Denomination: %d | Bills: %lu | Status: %s\n",
                lpUnit->usNumber,
                lpUnit->cUnitID,
                lpUnit->cCurrencyID,
                lpUnit->ulValues
